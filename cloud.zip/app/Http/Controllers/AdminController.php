<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\Division;
use App\Models\User;
use App\Utils\HttpResponse;
use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;

class AdminController extends Controller
{
    use HttpResponse;
    public function login()
    {
        $data['title'] = 'Login';
        return view('admin.login', $data);
    }
    public function index()
    {
        $data['title'] = 'Login';
        $data['applicants'] = User::with('choice1', 'choice2')->get();
        return view('admin.index', $data);
    }
    public function project()
    {
        $data['title'] = 'Project Links';
        $data['divisions'] = Division::all();
        return view('admin.project', $data);
    }

    public function updateLink(Request $request, Division $division)
    {
        $division->update(['project_link' => $request->link]);
        return $this->success('Link has been updated');
    }

    public function auth()
    {
        return Socialite::driver('google')->redirectUrl(env('GOOGLE_ADMIN_REDIRECT_URI'))->redirect();
    }

    public function processLogin(Request $request)
    {
        try {
            $user = Socialite::driver('google')->redirectUrl(env('GOOGLE_ADMIN_REDIRECT_URI'))->user();
            $email = $user->getEmail();
            $name = $user->getName();

            if (!str_ends_with($email, '@john.petra.ac.id')) {
                return redirect()->route('admin.login')->with('error', 'Please use your @john.petra.ac.id email');
            }


            $admin = Admin::where('email', $email)->first();
            if (!$admin) {
                return redirect()->route('admin.login')->with('error', 'You are not authorized');
            }

            $request->session()->put('id', $admin->id);
            $request->session()->put('email', $email);
            $request->session()->put('name', $name);

            if (str_ends_with($email, '@john.petra.ac.id')) {
                $request->session()->put('nrp', substr($email, 0, 9));
            }

            return redirect()->route('admin.index');
        } catch (\Exception $e) {
            return redirect()->route('admin.login')->with('error', $e->getMessage());
        }
    }

    public function validateInterview(Request $request)
    {
        $user = User::find($request->id);
        $user->update(['phase' => 3]);
        return $this->success('User has been validated');
    }
}
