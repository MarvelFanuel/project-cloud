<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\S3Controller;
use App\Http\Middleware\AdminMiddleware;
use App\Models\Admin;
use Illuminate\Support\Facades\Route;

Route::get('/', [MainController::class, 'index'])->name('index');

Route::get('/auth', [UserController::class, 'googleAuth'])->name('auth');
Route::get('/processLogin', [UserController::class, 'processLogin'])->name('processLogin');

Route::middleware('phaseCheck:0')->group(function () {
    Route::get('/biodata', [MainController::class, 'biodata'])->name('biodata');
    Route::post('/biodata', [UserController::class, 'storeBiodata'])->name('biodata.submit');
});

Route::middleware('phaseCheck:1')->group(function () {
    Route::get('/files', [MainController::class, 'files'])->name('files');
    Route::post('/files/{slug}', [UserController::class, 'storeFiles'])->name('files.store');
    Route::get('/files/check', [UserController::class, 'checkFiles'])->name('files.check');
});

Route::middleware('phaseCheck:2')->group(function () {
    Route::get('/schedule', [MainController::class, 'schedule'])->name('schedule');
    Route::get('/checkInterview', [UserController::class, 'checkInterview'])->name('checkInterview');
});

Route::middleware('phaseCheck:4')->group(function () {

    Route::get('/project', [MainController::class, 'project'])->name('project');
    Route::post('/project', [UserController::class, 'storeProject'])->name('project.submit');
});

Route::get('/logout', [MainController::class, 'logout'])->name('logout');

Route::get('admin/login', [AdminController::class, 'login'])->name('admin.login');
Route::get('admin/auth', [AdminController::class, 'auth'])->name('admin.auth');
Route::get('admin/processLogin', [AdminController::class, 'processLogin'])->name('admin.processLogin');

Route::prefix('admin')->name('admin.')->middleware(AdminMiddleware::class)->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('index');
    Route::get('/project', [AdminController::class, 'project'])->name('project');
    Route::put('/updateLink/{division:id}', [AdminController::class, 'updateLink'])->name('updateLink');
    Route::post('/validateInterview', [AdminController::class, 'validateInterview'])->name('validateInterview');
});

Route::get('/upload', function () {
    return view('upload');
});
Route::post('/upload', [S3Controller::class, 'uploadStore']);
Route::post('/upload/{slug}', [S3Controller::class, 'uploadStore'])->name('files.store');
