<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload File to S3</title>
</head>
<body>
    <h1>Upload File to S3</h1>

    <form action="<?php echo e(url('/upload')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="file">Select file:</label>
        <input type="file" name="file" id="file" required>
        <button type="submit">Upload</button>
    </form>

    <?php if(session('message')): ?>
        <p style="color: green;"><?php echo e(session('message')); ?></p>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <p style="color: red;"><?php echo e(session('error')); ?></p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Cloudcomp\project-cloud\resources\views/upload.blade.php ENDPATH**/ ?>