<?php $__env->startSection('head'); ?>
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.15)),
                linear-gradient(-45deg, rgba(99, 63, 146, 0.8), rgba(144, 38, 128, 0.8), rgba(196, 37, 85, 0.8));
            background-size: 400% 400%;
        }

        .peer {
            border-color: rgba(255, 255, 255 / 1) !important;
            color: var(--yellow) !important;
            font-size: 1.125rem !important;
            font-weight: 500;
        }

        .pointer-events-none {
            --tw-border-opacity: 1 !important;
            border-color: rgb(255 255 255 / var(--tw-border-opacity)) !important;
        }

        .data-\[te-select-open\]\:opacity-100[data-te-select-open] {
            /* background: linear-gradient(-45deg, rgba(41, 42, 103, 0.95), rgba(99, 63, 146, 0.95), rgba(144, 38, 128, 0.95)); */
            background: var(--neutral);
        }

        .data-\[te-select-open\]\:opacity-100[data-te-select-open] div div div span {
            /* color: var(--yellow); */
            color: white;
            font-size: 1.125rem !important;
            font-weight: 500;
        }

        svg {
            color: white;
        }

        .\[\&\:\:-webkit-scrollbar-thumb\]\:bg-\[\#999\]::-webkit-scrollbar-thumb {
            background: #f6ce3e !important;
        }

        .form-cont {
            box-shadow: 0 0 10px var(--yellow), 0 0 20px var(--yellow);
        }

        @media screen and (max-width:640px) {
            .data-\[te-select-open\]\:opacity-100[data-te-select-open] div div div span {
                font-size: 1rem !important;
            }

            .peer {
                font-size: 1rem !important;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="contents" enctype="multipart/form-data" id="files-form">
        <div
            class="form-cont lg:w-8/12 md:w-10/12 max-md:w-11/12 px-5 py-5 my-12 border-0 border-white bg-transparent h-auto rounded-xl">
            <h2 class="text-white text-3xl max-sm:text-2xl font-semibold italic">Ketentuan:</h2>
            <ul class="list-disc list-outside mb-5 ml-5">
                <li class="text-white font-medium text-lg max-sm:text-base">File harus harus berupa .jpg/.png/.jpeg</li>
                <li class="text-white font-medium text-lg max-sm:text-base">Ukuran upload maksimal 5MB / file</li>
                <li class="text-white font-medium text-lg max-sm:text-base">Data file tidak bisa diubah setelah form
                    tersubmit
                </li>
            </ul>
            <div class="grid grid-cols-2 max-xl:grid-cols-1 w-full gap-5 place-items-end">
                <div class="flex gap-x-4 items-end w-full">
                    <div class="w-full">
                        <label for="ktm" class="text-white mb-1 text-lg font-semibold max-lg:!text-base">Scan KTM /
                            Profile
                            Petra
                            Mobile</label>
                        <input
                            class="shadow-lg relative text-[var(--yellow)] text-lg m-0 block w-full min-w-0 flex-auto cursor-pointer rounded
                                 border border-solid border-white bg-transparent bg-clip-padding px-3 py-[0.32rem]
                                  max-lg:text-base font-medium text-surface transition duration-300 ease-in-out file:-mx-3
                                   file:-my-[0.32rem] file:me-3 file:cursor-pointer file:overflow-hidden file:rounded-none
                                    file:border-0 file:border-e file:border-solid file:border-inherit file:bg-[rgba(50,50,50,0.2)]
                                     file:px-3 file:text-white file:py-[0.32rem] file:text-surface focus:border-primary focus:shadow-inset
                                      focus:outline-none"
                            type="file" id="ktm" name="ktm" accept="image/*" />
                    </div>
                    <button type="button"
                        class="<?php echo e($files && $files->ktm ? 'bg-success' : 'bg-warning'); ?> text-white h-[39.93px] max-xl:h-[35.83px] max-lg:text-xs w-fit px-8 rounded text-sm font-medium tracking-wider"
                        onclick="upload('ktm')"
                        <?php echo e($files && $files->ktm ? 'disabled' : ''); ?>><?php echo e($files && $files->ktm ? 'UPLOADED' : 'UPLOAD'); ?></button>
                </div>
                <div class="flex gap-x-4 items-end w-full">
                    <div class="w-full">
                        <label for="grade" class="text-white mb-1 text-lg font-semibold max-lg:!text-base">Transkrip
                            KHS</label>
                        <input
                            class="shadow-lg relative text-[var(--yellow)] text-lg m-0 block w-full min-w-0 flex-auto cursor-pointer rounded
                                 border border-solid border-white bg-transparent bg-clip-padding px-3 py-[0.32rem]
                                  max-lg:text-base font-medium text-surface transition duration-300 ease-in-out file:-mx-3
                                   file:-my-[0.32rem] file:me-3 file:cursor-pointer file:overflow-hidden file:rounded-none
                                    file:border-0 file:border-e file:border-solid file:border-inherit file:bg-[rgba(50,50,50,0.2)]
                                     file:px-3 file:text-white file:py-[0.32rem] file:text-surface focus:border-primary focus:shadow-inset
                                      focus:outline-none"
                            type="file" id="grade" name="grade" accept="image/*" />
                    </div>
                    <button type="button"
                        class="<?php echo e($files && $files->grade ? 'bg-success' : 'bg-warning'); ?> text-white h-[39.93px] max-xl:h-[35.83px] max-lg:text-xs w-fit px-8 rounded text-sm font-medium tracking-wider"
                        onclick="upload('grade')"
                        <?php echo e($files && $files->grade ? 'disabled' : ''); ?>><?php echo e($files && $files->grade ? 'UPLOADED' : 'UPLOAD'); ?></button>

                </div>
                <div class="flex gap-x-4 items-end w-full">
                    <div class="w-full">
                        <label for="skkk" class="text-white mb-1 text-lg font-semibold max-lg:!text-base">Transkrip
                            SKKK</label>
                        <input
                            class="shadow-lg relative text-[var(--yellow)] text-lg m-0 block w-full min-w-0 flex-auto cursor-pointer rounded
                                 border border-solid border-white bg-transparent bg-clip-padding px-3 py-[0.32rem]
                                  max-lg:text-base font-medium text-surface transition duration-300 ease-in-out file:-mx-3
                                   file:-my-[0.32rem] file:me-3 file:cursor-pointer file:overflow-hidden file:rounded-none
                                    file:border-0 file:border-e file:border-solid file:border-inherit file:bg-[rgba(50,50,50,0.2)]
                                     file:px-3 file:text-white file:py-[0.32rem] file:text-surface focus:border-primary focus:shadow-inset
                                      focus:outline-none"
                            type="file" id="skkk" name="skkk" accept="image/*" />
                    </div>
                    <button type="button"
                        class="<?php echo e($files && $files->skkk ? 'bg-success' : 'bg-warning'); ?> text-white h-[39.93px] max-xl:h-[35.83px] max-lg:text-xs w-fit px-8 rounded text-sm font-medium tracking-wider"
                        onclick="upload('skkk')"
                        <?php echo e($files && $files->skkk ? 'disabled' : ''); ?>><?php echo e($files && $files->skkk ? 'UPLOADED' : 'UPLOAD'); ?></button>

                </div>
                <div class="flex gap-x-4 items-end w-full">
                    <div class="w-full">
                        <label for="cheats" class="text-white mb-1 text-lg font-semibold max-lg:!text-base">Bukti
                            Kecurangan</label>
                        <input
                            class="shadow-lg relative text-[var(--yellow)] text-lg m-0 block w-full min-w-0 flex-auto cursor-pointer rounded
                                 border border-solid border-white bg-transparent bg-clip-padding px-3 py-[0.32rem]
                                  max-lg:text-base font-medium text-surface transition duration-300 ease-in-out file:-mx-3
                                   file:-my-[0.32rem] file:me-3 file:cursor-pointer file:overflow-hidden file:rounded-none
                                    file:border-0 file:border-e file:border-solid file:border-inherit file:bg-[rgba(50,50,50,0.2)]
                                     file:px-3 file:text-white file:py-[0.32rem] file:text-surface focus:border-primary focus:shadow-inset
                                      focus:outline-none"
                            type="file" id="cheats" name="cheats" accept="image/*" />
                    </div>
                    <button type="button"
                        class="<?php echo e($files && $files->cheats ? 'bg-success' : 'bg-warning'); ?> text-white h-[39.93px] max-xl:h-[35.83px] max-lg:text-xs w-fit px-8 rounded text-sm font-medium tracking-wider"
                        onclick="upload('cheats')"
                        <?php echo e($files && $files->cheats ? 'disabled' : ''); ?>><?php echo e($files && $files->cheats ? 'UPLOADED' : 'UPLOAD'); ?></button>
                </div>

                <div class="flex gap-x-4 items-end w-full">
                    <div class="w-full">
                        <label for="photo" class="text-white mb-1 text-lg font-semibold max-lg:!text-base">Pas Foto
                            3x4</label>
                        <input
                            class="shadow-lg relative text-[var(--yellow)] text-lg m-0 block w-full min-w-0 flex-auto cursor-pointer rounded
                                 border border-solid border-white bg-transparent bg-clip-padding px-3 py-[0.32rem]
                                  max-lg:text-base font-medium text-surface transition duration-300 ease-in-out file:-mx-3
                                   file:-my-[0.32rem] file:me-3 file:cursor-pointer file:overflow-hidden file:rounded-none
                                    file:border-0 file:border-e file:border-solid file:border-inherit file:bg-[rgba(50,50,50,0.2)]
                                     file:px-3 file:text-white file:py-[0.32rem] file:text-surface focus:border-primary focus:shadow-inset
                                      focus:outline-none"
                            type="file" id="photo" name="photo" accept="image/*" />
                    </div>
                    <button type="button"
                        class="<?php echo e($files && $files->photo ? 'bg-success' : 'bg-warning'); ?> text-white h-[39.93px] max-xl:h-[35.83px] max-lg:text-xs w-fit px-8 rounded text-sm font-medium tracking-wider"
                        onclick="upload('photo')"
                        <?php echo e($files && $files->photo ? 'disabled' : ''); ?>><?php echo e($files && $files->photo ? 'UPLOADED' : 'UPLOAD'); ?></button>

                </div>
                <div class="w-full col-span-2 max-xl:col-span-1 mt-3">
                    <button type="button"
                        class="button-interact h-[50px] w-full rounded-lg border-2 border-white text-center text-xl text-[var(--yellow)] 
                font-semibold italic shadow-lg"
                        onclick="next()">Next</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function upload(slug) {
            Swal.fire({
                title: 'Uploading...',
                allowOutsideClick: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading()
                }
            })
            const file = document.getElementById(slug).files[0];
            const formData = new FormData();
            formData.append(slug, file);
            formData.append('_token', '<?php echo e(csrf_token()); ?>');
            fetch(`<?php echo e(route('files.store', '')); ?>/${slug}`, {
                    method: 'POST',
                    body: formData
                }).then(res => res.json())
                .then(data => {
                    if (data.success) {
                        document.querySelector(`button[onclick="upload('${slug}')"]`).classList.remove('bg-warning');
                        document.querySelector(`button[onclick="upload('${slug}')"]`).classList.add('bg-success');
                        document.querySelector(`button[onclick="upload('${slug}')"]`).textContent = 'UPLOADED';
                        document.querySelector(`button[onclick="upload('${slug}')`).setAttribute('disabled', '');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: data.message
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message
                        })
                    }
                }).catch(err => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Something went wrong'
                    })
                });
        }

        function next() {
            Swal.fire({
                title: 'Loading...',
                allowOutsideClick: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading()
                }
            });
            fetch(`<?php echo e(route('files.check')); ?>`, {
                    method: 'GET',
                }).then(res => res.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: data.message
                        }).then(() => {
                            window.location.href = '<?php echo e(route('schedule')); ?>';
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message,
                            didOpen: () => {
                                Swal.hideLoading();
                            }
                        });
                    }
                }).catch(err => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Something went wrong',
                        didOpen: () => {
                            Swal.hideLoading();
                        }
                    });
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.forms.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project Web\project-cloud\resources\views/user/forms/files.blade.php ENDPATH**/ ?>