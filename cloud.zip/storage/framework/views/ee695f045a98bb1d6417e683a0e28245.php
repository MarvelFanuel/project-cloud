


<?php $__env->startSection('content'); ?>
    <section class="w-screen flex justify-center py-24">
        <div class="w-[600px] flex flex-col justify-center items-center shadow-xl gap-4 p-8 border border-black rounded-xl">
            <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-full">
                    <p><?php echo e($division->name); ?></p>
                    <div class="flex gap-x-4">
                        <input type="text" value="<?php echo e($division->project_link); ?>" class="border border-black rounded w-full"
                            id="<?php echo e('division-' . $division->id); ?>">
                        <button class="bg-blue-500 text-white rounded px-4 py-2" data-te-ripple-init
                            data-te-ripple-color="light"
                            onclick="updateLink('<?php echo e($division->id); ?>', '<?php echo e($division->name); ?>')">Update</button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <script>
        function updateLink(id, name) {
            Swal.fire({
                title: "Update Project Link",
                text: `Are you sure to update ${name} link`,
                icon: "warning",
                showCancelButton: true,
            }).then((result) => {
                if (result.isConfirmed) {

                    const link = document.querySelector(`#division-${id}`).value;
                    fetch(`<?php echo e(route('admin.updateLink', '')); ?>/${id}`, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            },
                            body: JSON.stringify({
                                link: link
                            })
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    title: "Success!",
                                    icon: "success",
                                    text: data.message,
                                })
                            } else {
                                Swal.fire({
                                    title: "Error",
                                    icon: "error",
                                    text: data.message,
                                })
                            }
                        }).catch(err => {
                            Swal.fire({
                                title: "Error",
                                icon: "error",
                                text: "Something went wrong",
                            })
                        })
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Cloudcomp\project-cloud\resources\views/admin/project.blade.php ENDPATH**/ ?>